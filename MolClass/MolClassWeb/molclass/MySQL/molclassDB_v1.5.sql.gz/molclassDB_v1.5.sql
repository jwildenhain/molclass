-- MySQL dump 10.13  Distrib 5.5.32, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: molclass
-- ------------------------------------------------------
-- Server version	5.5.32-0ubuntu0.12.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `_seq`
--

DROP TABLE IF EXISTS `_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_seq` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_seq`
--

LOCK TABLES `_seq` WRITE;
/*!40000 ALTER TABLE `_seq` DISABLE KEYS */;
/*!40000 ALTER TABLE `_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth`
--

DROP TABLE IF EXISTS `auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth` (
  `r_uid` varchar(100) NOT NULL,
  `r_pw` varchar(40) NOT NULL,
  `r_fn` varchar(100) NOT NULL,
  `r_ln` varchar(100) NOT NULL,
  `r_email` varchar(200) NOT NULL,
  `r_as` varchar(150) NOT NULL,
  `r_loc` varchar(150) NOT NULL,
  `r_ip` char(17) NOT NULL,
  `lastlogin` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `r_title` char(4) NOT NULL,
  `r_ts` date NOT NULL,
  `btnSubmit` varchar(6) NOT NULL,
  `r_pw_conf` varchar(40) NOT NULL,
  `r_login` varchar(20) NOT NULL,
  PRIMARY KEY (`r_uid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth`
--

LOCK TABLES `auth` WRITE;
/*!40000 ALTER TABLE `auth` DISABLE KEYS */;
INSERT INTO `auth` VALUES ('b604bb72dcbf84dc8835558360dfdc35','1c13a3353c4ec439441180478c7fbb9c','Admin','Admin','root@localhost.org','MolClass','root','','2013-05-20 21:59:58','Dr','0000-00-00','Submit','1c13a3353c4ec439441180478c7fbb9c',''),('06ede210089278a57605937894843c25','1c13a3353c4ec439441180478c7fbb9c','Author','Author','jan.wildenhain@ed.ac.uk','University of Edinburgh','UK','','2013-05-20 22:02:27','Mr','0000-00-00','Submit','1c13a3353c4ec439441180478c7fbb9c','');
/*!40000 ALTER TABLE `auth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batchlist`
--

DROP TABLE IF EXISTS `batchlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batchlist` (
  `batch_id` int(11) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `filename` varchar(100) NOT NULL,
  `tags` text NOT NULL,
  `mol_type` varchar(20) NOT NULL,
  `pmid` varchar(20) DEFAULT NULL,
  `info` text,
  `uploaded` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`batch_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batchlist`
--

LOCK TABLES `batchlist` WRITE;
/*!40000 ALTER TABLE `batchlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `batchlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batchmols`
--

DROP TABLE IF EXISTS `batchmols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batchmols` (
  `mol_id` int(8) unsigned zerofill NOT NULL DEFAULT '00000000',
  `batch_id` int(11) unsigned zerofill NOT NULL DEFAULT '00000000000',
  UNIQUE KEY `mol_id` (`mol_id`,`batch_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batchmols`
--

LOCK TABLES `batchmols` WRITE;
/*!40000 ALTER TABLE `batchmols` DISABLE KEYS */;
/*!40000 ALTER TABLE `batchmols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cdk_descriptors`
--

DROP TABLE IF EXISTS `cdk_descriptors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cdk_descriptors` (
  `mol_id` int(8) unsigned zerofill NOT NULL DEFAULT '00000000',
  `nA` int(5) DEFAULT NULL,
  `nR` int(5) DEFAULT NULL,
  `nN` int(5) DEFAULT NULL,
  `nD` int(5) DEFAULT NULL,
  `nC` int(5) DEFAULT NULL,
  `nF` int(5) DEFAULT NULL,
  `nQ` int(5) DEFAULT NULL,
  `nE` int(5) DEFAULT NULL,
  `nG` int(5) DEFAULT NULL,
  `nH` int(5) DEFAULT NULL,
  `nI` int(5) DEFAULT NULL,
  `nP` int(5) DEFAULT NULL,
  `nL` int(5) DEFAULT NULL,
  `nK` int(5) DEFAULT NULL,
  `nM` int(5) DEFAULT NULL,
  `nS` int(5) DEFAULT NULL,
  `nT` int(5) DEFAULT NULL,
  `nY` int(5) DEFAULT NULL,
  `nV` int(5) DEFAULT NULL,
  `nW` int(5) DEFAULT NULL,
  `apol` double DEFAULT NULL,
  `naAromAtom` int(5) DEFAULT NULL,
  `nAromBond` int(5) DEFAULT NULL,
  `nAtom` int(5) DEFAULT NULL,
  `ATSc1` double DEFAULT NULL,
  `ATSc2` double DEFAULT NULL,
  `ATSc3` double DEFAULT NULL,
  `ATSc4` double DEFAULT NULL,
  `ATSc5` double DEFAULT NULL,
  `ATSm1` double DEFAULT NULL,
  `ATSm2` double DEFAULT NULL,
  `ATSm3` double DEFAULT NULL,
  `ATSm4` double DEFAULT NULL,
  `ATSm5` double DEFAULT NULL,
  `ATSp1` double DEFAULT NULL,
  `ATSp2` double DEFAULT NULL,
  `ATSp3` double DEFAULT NULL,
  `ATSp4` double DEFAULT NULL,
  `ATSp5` double DEFAULT NULL,
  `BCUTw_1l` double DEFAULT NULL,
  `BCUTw_1h` double DEFAULT NULL,
  `BCUTc_1l` double DEFAULT NULL,
  `BCUTc_1h` double DEFAULT NULL,
  `BCUTp_1l` double DEFAULT NULL,
  `BCUTp_1h` double DEFAULT NULL,
  `nB` int(5) DEFAULT NULL,
  `bpol` double DEFAULT NULL,
  `chi0C` double DEFAULT NULL,
  `chi1C` double DEFAULT NULL,
  `SCH_3` double DEFAULT NULL,
  `SCH_4` double DEFAULT NULL,
  `SCH_5` double DEFAULT NULL,
  `SCH_6` double DEFAULT NULL,
  `VCH_3` double DEFAULT NULL,
  `VCH_4` double DEFAULT NULL,
  `VCH_5` double DEFAULT NULL,
  `VCH_6` double DEFAULT NULL,
  `SC_3` double DEFAULT NULL,
  `SC_4` double DEFAULT NULL,
  `SC_5` double DEFAULT NULL,
  `SC_6` double DEFAULT NULL,
  `SPC_4` double DEFAULT NULL,
  `SPC_5` double DEFAULT NULL,
  `SPC_6` double DEFAULT NULL,
  `VPC_4` double DEFAULT NULL,
  `VPC_5` double DEFAULT NULL,
  `VPC_6` double DEFAULT NULL,
  `VC_3` double DEFAULT NULL,
  `VC_4` double DEFAULT NULL,
  `VC_5` double DEFAULT NULL,
  `VC_6` double DEFAULT NULL,
  `VP_8` double DEFAULT NULL,
  `VP_9` double DEFAULT NULL,
  `VP_10` double DEFAULT NULL,
  `VP_11` double DEFAULT NULL,
  `VP_12` double DEFAULT NULL,
  `VP_13` double DEFAULT NULL,
  `VP_14` double DEFAULT NULL,
  `VP_15` double DEFAULT NULL,
  `SP_0` double DEFAULT NULL,
  `SP_1` double DEFAULT NULL,
  `SP_2` double DEFAULT NULL,
  `SP_3` double DEFAULT NULL,
  `SP_4` double DEFAULT NULL,
  `SP_5` double DEFAULT NULL,
  `SP_6` double DEFAULT NULL,
  `SP_7` double DEFAULT NULL,
  `PPSA_1` double DEFAULT NULL,
  `PPSA_2` double DEFAULT NULL,
  `PPSA_3` double DEFAULT NULL,
  `PNSA_1` double DEFAULT NULL,
  `PNSA_2` double DEFAULT NULL,
  `PNSA_3` double DEFAULT NULL,
  `DPSA_1` double DEFAULT NULL,
  `DPSA_2` double DEFAULT NULL,
  `DPSA_3` double DEFAULT NULL,
  `FPSA_1` double DEFAULT NULL,
  `FPSA_2` double DEFAULT NULL,
  `FPSA_3` double DEFAULT NULL,
  `FNSA_1` double DEFAULT NULL,
  `FNSA_2` double DEFAULT NULL,
  `FNSA_3` double DEFAULT NULL,
  `WPSA_1` double DEFAULT NULL,
  `WPSA_2` double DEFAULT NULL,
  `WPSA_3` double DEFAULT NULL,
  `WNSA_1` double DEFAULT NULL,
  `WNSA_2` double DEFAULT NULL,
  `WNSA_3` double DEFAULT NULL,
  `RPCG` double DEFAULT NULL,
  `RNCG` double DEFAULT NULL,
  `RPCS` double DEFAULT NULL,
  `RNCS` double DEFAULT NULL,
  `THSA` double DEFAULT NULL,
  `TPSA` double DEFAULT NULL,
  `RHSA` double DEFAULT NULL,
  `RPSA` double DEFAULT NULL,
  `ECCEN` int(5) DEFAULT NULL,
  `fragC` double DEFAULT NULL,
  `nHBAcc` int(5) DEFAULT NULL,
  `nHBDon` int(5) DEFAULT NULL,
  `Kier1` double DEFAULT NULL,
  `Kier2` double DEFAULT NULL,
  `Kier3` double DEFAULT NULL,
  `nAtomP` int(5) DEFAULT NULL,
  `nAtomLAC` int(5) DEFAULT NULL,
  `nAtomLC` int(5) DEFAULT NULL,
  `MDEC_11` double DEFAULT NULL,
  `MDEC_12` double DEFAULT NULL,
  `MDEC_13` double DEFAULT NULL,
  `MDEC_14` double DEFAULT NULL,
  `MDEC_22` double DEFAULT NULL,
  `MDEC_23` double DEFAULT NULL,
  `MDEC_24` double DEFAULT NULL,
  `MDEC_33` double DEFAULT NULL,
  `MDEC_34` double DEFAULT NULL,
  `MDEC_44` double DEFAULT NULL,
  `MDEO_11` double DEFAULT NULL,
  `MDEO_12` double DEFAULT NULL,
  `MDEO_22` double DEFAULT NULL,
  `MDEN_11` double DEFAULT NULL,
  `MDEN_12` double DEFAULT NULL,
  `MDEN_13` double DEFAULT NULL,
  `MDEN_22` double DEFAULT NULL,
  `MDEN_23` double DEFAULT NULL,
  `MDEN_33` double DEFAULT NULL,
  `PetitjeanNumber` double DEFAULT NULL,
  `nRotB` int(5) DEFAULT NULL,
  `TopoPSA` double DEFAULT NULL,
  `VABC` double DEFAULT NULL,
  `vAdjMat` double DEFAULT NULL,
  `chi0vC` double DEFAULT NULL,
  `chi1vC` double DEFAULT NULL,
  `MW` double DEFAULT NULL,
  `WPATH` double DEFAULT NULL,
  `WPOL` double DEFAULT NULL,
  `XLogP` double DEFAULT NULL,
  `Zagreb` double DEFAULT NULL,
  `DoubleResult` double DEFAULT NULL,
  `ALogP` double DEFAULT NULL,
  `ALogP2` double DEFAULT NULL,
  `nAcid` int(4) DEFAULT NULL,
  `nBase` int(4) DEFAULT NULL,
  `C1SP1` int(4) DEFAULT NULL,
  `SCH_7` double DEFAULT NULL,
  `VP_0` double DEFAULT NULL,
  `FMF` double DEFAULT NULL,
  `HybRatio` double DEFAULT NULL,
  `khs_sLi` double DEFAULT NULL,
  `MLogP` double DEFAULT NULL,
  `topoShape` double DEFAULT NULL,
  `AMR` double DEFAULT NULL,
  `khs_ssBe` double DEFAULT NULL,
  `LipinskiFailures` int(4) DEFAULT NULL,
  `WTPT_3` double DEFAULT NULL,
  `C2SP1` int(4) DEFAULT NULL,
  `VCH_7` double DEFAULT NULL,
  `VP_1` double DEFAULT NULL,
  `C1SP2` int(4) DEFAULT NULL,
  `VP_2` double DEFAULT NULL,
  `khs_ssssBe` double DEFAULT NULL,
  `VP_3` double DEFAULT NULL,
  `C2SP2` int(4) DEFAULT NULL,
  `khs_ssBH` double DEFAULT NULL,
  `WTPT1` double DEFAULT NULL,
  `khs_sssB` double DEFAULT NULL,
  `C3SP2` int(4) DEFAULT NULL,
  `WTPT_4` double DEFAULT NULL,
  `VP_4` double DEFAULT NULL,
  `WTPT_5` double DEFAULT NULL,
  `khs_ssssB` double DEFAULT NULL,
  `C1SP3` int(4) DEFAULT NULL,
  `VP_5` double DEFAULT NULL,
  `khs_sCH3` double DEFAULT NULL,
  `C2SP3` int(4) DEFAULT NULL,
  `VP_6` double DEFAULT NULL,
  `khs_dCH2` double DEFAULT NULL,
  `C3SP3` int(4) DEFAULT NULL,
  `VP_7` double DEFAULT NULL,
  `khs_ssCH2` double DEFAULT NULL,
  `WTPT_1` double DEFAULT NULL,
  `WTPT_2` double DEFAULT NULL,
  `khs_tCH` double DEFAULT NULL,
  `C4SP3` int(4) DEFAULT NULL,
  `khs_dsCH` double DEFAULT NULL,
  `khs_aaCH` double DEFAULT NULL,
  `khs_sssCH` double DEFAULT NULL,
  `khs_ddC` double DEFAULT NULL,
  `khs_tsC` double DEFAULT NULL,
  `khs_dssC` double DEFAULT NULL,
  `khs_aasC` double DEFAULT NULL,
  `khs_aaaC` double DEFAULT NULL,
  `khs_ssssC` double DEFAULT NULL,
  `khs_sNH3` double DEFAULT NULL,
  `khs_sNH2` double DEFAULT NULL,
  `khs_ssNH2` double DEFAULT NULL,
  `khs_dNH` double DEFAULT NULL,
  `khs_ssNH` double DEFAULT NULL,
  `khs_aaNH` double DEFAULT NULL,
  `khs_tNH` double DEFAULT NULL,
  `khs_tN` double DEFAULT NULL,
  `khs_sssNH` double DEFAULT NULL,
  `khs_dsN` double DEFAULT NULL,
  `khs_aaN` double DEFAULT NULL,
  PRIMARY KEY (`mol_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cdk_descriptors`
--

LOCK TABLES `cdk_descriptors` WRITE;
/*!40000 ALTER TABLE `cdk_descriptors` DISABLE KEYS */;
/*!40000 ALTER TABLE `cdk_descriptors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `class_models`
--

DROP TABLE IF EXISTS `class_models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `class_models` (
  `model_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) DEFAULT NULL,
  `model_data` longblob,
  `header` longblob,
  `classes` text,
  `username` varchar(100) DEFAULT NULL,
  `batch_id` int(11) DEFAULT NULL,
  `data_type` varchar(10) DEFAULT NULL,
  `class_tag` varchar(40) DEFAULT NULL,
  `class_scheme` varchar(30) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `printout` longtext,
  PRIMARY KEY (`model_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `class_models`
--

LOCK TABLES `class_models` WRITE;
/*!40000 ALTER TABLE `class_models` DISABLE KEYS */;
/*!40000 ALTER TABLE `class_models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `class_schemes`
--

DROP TABLE IF EXISTS `class_schemes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `class_schemes` (
  `class_scheme` varchar(30) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `class_schemes`
--

LOCK TABLES `class_schemes` WRITE;
/*!40000 ALTER TABLE `class_schemes` DISABLE KEYS */;
INSERT INTO `class_schemes` VALUES ('RandomForest'),('LMT'),('J48'),('NaiveBayes'),('KNN'),('SMO'),('LibSVM'),('LogitBoost'),('RacedIncrementalLogitBoost'),('Ensemble'),('NBTree'),('HiddenNaiveBayes'),('DecisionTreeNaiveBayes'),('LibSVM2'),('BayesNet'),('NeuralNet'),('Ensemble2');
/*!40000 ALTER TABLE `class_schemes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_types`
--

DROP TABLE IF EXISTS `data_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_types` (
  `data_type` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_types`
--

LOCK TABLES `data_types` WRITE;
/*!40000 ALTER TABLE `data_types` DISABLE KEYS */;
INSERT INTO `data_types` VALUES ('CDK'),('MACCS'),('ALL'),('PubChem'),('EXT'),('EXTGO'),('KR'),('SUB'),('JUMBO'),('MCAT'),('GO');
/*!40000 ALTER TABLE `data_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fingerprints`
--

DROP TABLE IF EXISTS `fingerprints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fingerprints` (
  `mol_id` int(8) unsigned zerofill NOT NULL DEFAULT '00000000',
  `MACCS` text,
  `EXT` text,
  `PubChem` text,
  `KR` text,
  `SUB` text,
  `GOFP` text,
  `ESFP` text,
  PRIMARY KEY (`mol_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fingerprints`
--

LOCK TABLES `fingerprints` WRITE;
/*!40000 ALTER TABLE `fingerprints` DISABLE KEYS */;
/*!40000 ALTER TABLE `fingerprints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inchi_key`
--

DROP TABLE IF EXISTS `inchi_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inchi_key` (
  `mol_id` int(11) NOT NULL,
  `inchi_key` char(35) DEFAULT NULL,
  `mol_type` varchar(20) DEFAULT 'learn',
  `smiles` text,
  `inchi` mediumtext,
  PRIMARY KEY (`mol_id`),
  KEY `inchi_key` (`inchi_key`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inchi_key`
--

LOCK TABLES `inchi_key` WRITE;
/*!40000 ALTER TABLE `inchi_key` DISABLE KEYS */;
/*!40000 ALTER TABLE `inchi_key` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moldb_fpdef`
--

DROP TABLE IF EXISTS `moldb_fpdef`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `moldb_fpdef` (
  `fp_id` int(11) DEFAULT NULL,
  `fpdef` mediumblob,
  `fptype` smallint(6) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moldb_fpdef`
--

LOCK TABLES `moldb_fpdef` WRITE;
/*!40000 ALTER TABLE `moldb_fpdef` DISABLE KEYS */;
INSERT INTO `moldb_fpdef` VALUES (1,'C1CC1 cyclopropane\n  CheckMol                        TMF02:r0:m0\n\n  3  3  0  1  0               999 V2000\n    1.4000    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.7000    1.2124    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  1  0  1  0  0\n  1  3  1  0  1  0  0\n  2  3  1  0  1  0  0\nM  END\n\n$$$$ \nC1=CC1 cyclopropene\n  CheckMol                        TMF02:r0:m0\n\n  3  3  0  1  0               999 V2000\n    1.4000    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.7000    1.2124    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  2  0  1  0  0\n  1  3  1  0  1  0  0\n  2  3  1  0  1  0  0\nM  END\n\n$$$$ \nC1CCC1 cyclobutane\n  CheckMol                        TMF02:r0:m0\n\n  4  4  0  1  0               999 V2000\n    1.4000    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.4000    1.4000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.4000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  1  0  1  0  0\n  1  3  1  0  1  0  0\n  2  4  1  0  1  0  0\n  3  4  1  0  1  0  0\nM  END\n\n$$$$ \nC1=CCC1 cyclobutene\n  CheckMol                        TMF02:r0:m0\n\n  4  4  0  1  0               999 V2000\n    1.4000    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.4000    1.4000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.4000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  2  0  1  0  0\n  1  3  1  0  1  0  0\n  2  4  1  0  1  0  0\n  3  4  1  0  1  0  0\nM  END\n\n$$$$ \nc1ccc1 cyclobutadiene\n  CheckMol                        TMF02:r0:m0\n\n  4  4  0  1  0               999 V2000\n    0.0000    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.4000    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.4000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.4000    1.4000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  2  0  1  0  0\n  1  3  1  0  1  0  0\n  2  4  1  0  1  0  0\n  3  4  2  0  1  0  0\nM  END\n\n$$$$ \nC1CCCC1 cyclopentane\n  CheckMol                        TMF02:r0:m0\n\n  5  5  0  1  0               999 V2000\n    1.8326    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.2652    1.3315    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.4326    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.1326    2.1544    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.3315    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  1  0  1  0  0\n  1  3  1  0  1  0  0\n  2  4  1  0  1  0  0\n  3  5  1  0  1  0  0\n  4  5  1  0  1  0  0\nM  END\n\n$$$$ \nC1=CCCC1 cyclopentene\n  CheckMol                        TMF02:r0:m0\n\n  5  5  0  1  0               999 V2000\n    0.4326    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.3315    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.8326    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.1326    2.1544    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.2652    1.3315    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  2  0  1  0  0\n  1  3  1  0  1  0  0\n  2  4  1  0  1  0  0\n  3  5  1  0  1  0  0\n  4  5  1  0  1  0  0\nM  END\n\n$$$$ \nC1=CCC=C1 cyclopentadiene\n  CheckMol                        TMF02:r0:m0\n\n  5  5  0  1  0               999 V2000\n    0.4300    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.8301    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.3301    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.2601    1.3301    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.1300    2.1601    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  1  0  1  0  0\n  1  3  2  0  1  0  0\n  2  4  2  0  1  0  0\n  3  5  1  0  1  0  0\n  4  5  1  0  1  0  0\nM  END\n\n$$$$ \nC1CCCCC1 cyclohexane\n  CheckMol                        TMF02:r0:m0\n\n  6  6  0  1  0               999 V2000\n    2.4249    0.7000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.4249    2.1000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.2124    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.2124    2.8000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    0.7000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.1000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  1  0  1  0  0\n  1  3  1  0  1  0  0\n  2  4  1  0  1  0  0\n  3  5  1  0  1  0  0\n  4  6  1  0  1  0  0\n  5  6  1  0  1  0  0\nM  END\n\n$$$$ \nC1=CCCCC1 cyclohexene\n  CheckMol                        TMF02:r0:m0\n\n  6  6  0  1  0               999 V2000\n    0.0000    0.7000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.1000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.2124    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.2124    2.8000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.4249    0.7000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.4249    2.1000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  2  0  1  0  0\n  1  3  1  0  1  0  0\n  2  4  1  0  1  0  0\n  3  5  1  0  1  0  0\n  4  6  1  0  1  0  0\n  5  6  1  0  1  0  0\nM  END\n\n$$$$ \nC1=CCCC=C1 cyclohexa-1,3-diene\n  CheckMol                        TMF02:r0:m0\n\n  6  6  0  1  0               999 V2000\n    0.0000    0.6993    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.2087    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.0978    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.4274    0.6993    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.2087    2.7970    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.4274    2.0978    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  1  0  1  0  0\n  1  3  2  0  1  0  0\n  2  4  2  0  1  0  0\n  3  5  1  0  1  0  0\n  4  6  1  0  1  0  0\n  5  6  1  0  1  0  0\nM  END\n\n$$$$ \nC1=CCC=CC1 cyclohexa-1,4-diene\n  CheckMol                        TMF02:r0:m0\n\n  6  6  0  1  0               999 V2000\n    0.0000    0.6993    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.0978    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.4274    0.6993    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.4274    2.0978    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.2087    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.2087    2.7970    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  2  0  1  0  0\n  1  5  1  0  1  0  0\n  2  6  1  0  1  0  0\n  3  4  2  0  1  0  0\n  3  5  1  0  1  0  0\n  4  6  1  0  1  0  0\nM  END\n\n$$$$ \nc1ccccc1 benzene\n  CheckMol                        TMF02:r0:m0\n\n  6  6  0  1  0               999 V2000\n    2.4249    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4249    2.1000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2124    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2124    2.8000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.1000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 01  0  1  0  0\n  1  3 02  0  1  0  0\n  2  4 02  0  1  0  0\n  3  5 01  0  1  0  0\n  4  6 01  0  1  0  0\n  5  6 02  0  1  0  0\nM  END\n\n$$$$ \nC1CCCCCC1 cycloheptane\n  CheckMol                        TMF02:r0:m0\n\n  7  7  0  1  0               999 V2000\n    2.2729    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    3.1458    1.0946    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.8729    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.8342    2.4595    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.0946    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.5729    3.0669    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.3115    2.4595    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  1  0  1  0  0\n  1  3  1  0  1  0  0\n  2  4  1  0  1  0  0\n  3  5  1  0  1  0  0\n  4  6  1  0  1  0  0\n  5  7  1  0  1  0  0\n  6  7  1  0  1  0  0\nM  END\n\n$$$$ \nC1=CCCCCC1 cycloheptene\nJME 2003.05 Thu Dec 01 15:00:19 CET 2005\n\n  7  7  0  0  0  0  0  0  0  0999 V2000\n    2.2729    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.8729    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    3.1458    1.0946    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.0946    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.8342    2.4595    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.3115    2.4595    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.5729    3.0669    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  2  0  0  0  0\n  1  3  1  0  0  0  0\n  2  4  1  0  0  0  0\n  3  5  1  0  0  0  0\n  4  6  1  0  0  0  0\n  5  7  1  0  0  0  0\n  6  7  1  0  0  0  0\nM  END\n\n$$$$ \nC1=CCCC=CC1 cyclohepta-1,4-diene\n  CheckMol                        TMF02:r0:m0\n\n  7  7  0  1  0               999 V2000\n    0.8709    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.3103    2.4626    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.2724    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.5717    3.0632    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.0912    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    3.1433    1.0912    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.8330    2.4626    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n  1  3  2  0  1  0  0\n  1  5  1  0  1  0  0\n  2  4  2  0  1  0  0\n  2  5  1  0  1  0  0\n  3  6  1  0  1  0  0\n  4  7  1  0  1  0  0\n  6  7  1  0  1  0  0\nM  END\n\n$$$$ \nC1=CC=CCC=C1 cycloheptatriene\n  CheckMol                        TMF02:r0:m0\n\n  7  7  0  1  0               999 V2000\n    2.8330    2.4626    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    3.1433    1.0912    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.5717    3.0632    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.2724    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.3103    2.4626    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.8709    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.0912    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  2  0  1  0  0\n  1  3  1  0  1  0  0\n  2  4  1  0  1  0  0\n  3  5  2  0  1  0  0\n  4  6  2  0  1  0  0\n  5  7  1  0  1  0  0\n  6  7  1  0  1  0  0\nM  END\n\n$$$$ \nC1CCCCCCC1 cyclooctane\n  CheckMol                        TMF02:r0:m0\n\n  8  8  0  1  0               999 V2000\n    2.3899    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    3.3799    0.9899    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.9899    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    3.3799    2.3899    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    0.9899    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.3899    3.3799    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.3899    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.9899    3.3799    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  1  0  1  0  0\n  1  3  1  0  1  0  0\n  2  4  1  0  1  0  0\n  3  5  1  0  1  0  0\n  4  6  1  0  1  0  0\n  5  7  1  0  1  0  0\n  6  8  1  0  1  0  0\n  7  8  1  0  1  0  0\nM  END\n\n$$$$ \nC1=CCCCCCC1 cyclooctene\n  CheckMol                        TMF02:r0:m0\n\n  8  8  0  1  0               999 V2000\n    2.3899    3.3799    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.9899    3.3799    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    3.3799    2.3899    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.3899    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    3.3799    0.9899    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    0.9899    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.3899    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.9899    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  2  0  1  0  0\n  1  3  1  0  1  0  0\n  2  4  1  0  1  0  0\n  3  5  1  0  1  0  0\n  4  6  1  0  1  0  0\n  5  7  1  0  1  0  0\n  6  8  1  0  1  0  0\n  7  8  1  0  1  0  0\nM  END\n\n$$$$ \nC1CN1 aziridine\n  CheckMol                        TMF02:r0:m0\n\n  3  3  0  1  0               999 V2000\n    1.4000    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.7000    1.2124    0.0000 N   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  1  0  1  0  0\n  1  3  1  0  1  0  0\n  2  3  1  0  1  0  0\nM  END\n\n$$$$ \nazirine system with all bond types set to _any_\n  -ISIS-  12160513102D\n\n  3  3  0  0  0  0  0  0  0  0999 V2000\n    3.8792   -2.6708    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    5.2806   -2.6708    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    4.5799   -1.4596    0.0000 N   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  8  0  0  0  0\n  1  3  8  0  0  0  0\n  2  3  8  0  0  0  0\nM  END\n\n$$$$ \nC1CO1 epoxide\n  CheckMol                        TMF02:r0:m0\n\n  3  3  0  1  0               999 V2000\n    1.4000    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.7000    1.2124    0.0000 O   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  1  0  1  0  0\n  1  3  1  0  1  0  0\n  2  3  1  0  1  0  0\nM  END\n\n$$$$ \nC1CNC1 azetidine\n  CheckMol                        TMF02:r0:m0\n\n  4  4  0  1  0               999 V2000\n    0.0000    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.4000    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.4000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.4000    1.4000    0.0000 N   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  1  0  1  0  0\n  1  3  1  0  1  0  0\n  2  4  1  0  1  0  0\n  3  4  1  0  1  0  0\nM  END\n\n$$$$ \nO=C1CCN1 beta-lactam\n  CheckMol                        TMF02:r0:m0\n\n  5  5  0  1  0               999 V2000\n    0.0000    2.3899    0.0000 O   0  0  0  0  0  0  0  0  0  0  0  0\n    2.3899    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.9899    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.3899    1.4000    0.0000 N   0  0  0  0  0  0  0  0  0  0  0  0\n    0.9899    1.4000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n  1  5  2  0  0  0  0\n  2  3  1  0  1  0  0\n  2  4  1  0  1  0  0\n  3  5  1  0  1  0  0\n  4  5  1  0  1  0  0\nM  END\n\n$$$$ \nC1CCNC1 pyrrolidine\n  CheckMol                        TMF02:r0:m0\n\n  5  5  0  1  0               999 V2000\n    0.4289    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.8253    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.3365    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.2641    1.3365    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.1271    2.1544    0.0000 N   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  1  0  1  0  0\n  1  3  1  0  1  0  0\n  2  4  1  0  1  0  0\n  3  5  1  0  1  0  0\n  4  5  1  0  1  0  0\nM  END\n\n$$$$ \nC1=CNCC1 2-pyrroline\n  CheckMol                        TMF02:r0:m0\n\n  5  5  0  1  0               999 V2000\n    0.4307    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.3422    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.8230    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.2638    1.3422    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.1319    2.1536    0.0000 N   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  2  0  1  0  0\n  1  3  1  0  1  0  0\n  2  5  1  0  1  0  0\n  3  4  1  0  1  0  0\n  4  5  1  0  1  0  0\nM  END\n\n$$$$ \nC1=CCNC1 3-pyrroline\n  CheckMol                        TMF02:r0:m0\n\n  5  5  0  1  0               999 V2000\n    0.4296    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.8283    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.3388    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.2679    1.3388    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.1389    2.1480    0.0000 N   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  2  0  1  0  0\n  1  3  1  0  1  0  0\n  2  4  1  0  1  0  0\n  3  5  1  0  1  0  0\n  4  5  1  0  1  0  0\nM  END\n\n$$$$ \nc1cc[nH]c1 pyrrole\n  CheckMol                        TMF02:r0:m0\n\n  5  5  0  1  0               999 V2000\n    1.8326    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.4326    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.2652    1.3315    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.3315    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.1326    2.1544    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 01  0  1  0  0\n  1  3 02  0  1  0  0\n  2  4 02  0  1  0  0\n  3  5 01  0  1  0  0\n  4  5 01  0  1  0  0\nM  END\n\n$$$$ \nC1CCOC1 tetrahydrofuran\n  CheckMol                        TMF02:r0:m0\n\n  5  5  0  1  0               999 V2000\n    0.4307    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.8332    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.3323    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.2639    1.3323    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.1320    2.1537    0.0000 O   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  1  0  1  0  0\n  1  3  1  0  1  0  0\n  2  4  1  0  1  0  0\n  3  5  1  0  1  0  0\n  4  5  1  0  1  0  0\nM  END\n\n$$$$ \nc1ccoc1 furan\n  CheckMol                        TMF02:r0:m0\n\n  5  5  0  1  0               999 V2000\n    1.8282    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.4296    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.2578    1.3387    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.3387    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.1289    2.1579    0.0000 O   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 01  0  1  0  0\n  1  3 02  0  1  0  0\n  2  4 02  0  1  0  0\n  3  5 01  0  1  0  0\n  4  5 01  0  1  0  0\nM  END\n\n$$$$ \nc1ccsc1 thiophene\n  CheckMol                        TMF02:r0:m0\n\n  5  5  0  1  0               999 V2000\n    0.4303    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.8312    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.3409    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.2615    1.3409    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.1308    2.1515    0.0000 S   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 01  0  1  0  0\n  1  3 02  0  1  0  0\n  2  4 02  0  1  0  0\n  3  5 01  0  1  0  0\n  4  5 01  0  1  0  0\nM  END\n\n$$$$ \nc1cn[nH]c1 pyrazole\n  CheckMol                        TMF02:r0:m0\n\n  5  5  0  1  0               999 V2000\n    0.4303    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.8312    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.3409    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.2615    1.3409    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    1.1308    2.1515    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 01  0  1  0  0\n  1  3 02  0  1  0  0\n  2  4 02  0  1  0  0\n  3  5 01  0  1  0  0\n  4  5 01  0  1  0  0\nM  END\n\n$$$$ \nc1c[nH]cn1 imidazole\n  CheckMol                        TMF02:r0:m0\n\n  5  5  0  1  0               999 V2000\n    0.4303    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.3409    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.2615    1.3409    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.8312    0.0000    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    1.1308    2.1515    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 02  0  1  0  0\n  1  4 01  0  1  0  0\n  2  5 01  0  1  0  0\n  3  4 02  0  1  0  0\n  3  5 01  0  1  0  0\nM  END\n\n$$$$ \nc1nnc[nH]1 1,2,4-triazole\n  CheckMol                        TMF02:r0:m0\n\n  5  5  0  1  0               999 V2000\n    0.0000    1.3409    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.2615    1.3409    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.4303    0.0000    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    1.8312    0.0000    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    1.1308    2.1515    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n  1  3 02  0  1  0  0\n  1  5 01  0  1  0  0\n  2  4 02  0  1  0  0\n  2  5 01  0  1  0  0\n  3  4 01  0  1  0  0\nM  END\n\n$$$$ \nc1nnn[nH]1 tetrazole\n  CheckMol                        TMF02:r0:m0\n\n  5  5  0  1  0               999 V2000\n    0.0000    1.3409    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.4303    0.0000    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    1.8312    0.0000    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    2.2615    1.3409    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    1.1308    2.1515    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 02  0  1  0  0\n  1  5 01  0  1  0  0\n  2  3 01  0  1  0  0\n  3  4 02  0  1  0  0\n  4  5 01  0  1  0  0\nM  END\n\n$$$$ \nc1cnoc1 isoxazole\n  CheckMol                        TMF02:r0:m0\n\n  5  5  0  1  0               999 V2000\n    0.4303    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.8312    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.3409    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.2615    1.3409    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    1.1308    2.1515    0.0000 O   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 01  0  1  0  0\n  1  3 02  0  1  0  0\n  2  4 02  0  1  0  0\n  3  5 01  0  1  0  0\n  4  5 01  0  1  0  0\nM  END\n\n$$$$ \nc1cocn1 oxazole\n  CheckMol                        TMF02:r0:m0\n\n  5  5  0  1  0               999 V2000\n    0.4303    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.3409    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.2615    1.3409    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.8312    0.0000    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    1.1308    2.1515    0.0000 O   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 02  0  1  0  0\n  1  4 01  0  1  0  0\n  2  5 01  0  1  0  0\n  3  4 02  0  1  0  0\n  3  5 01  0  1  0  0\nM  END\n\n$$$$ \nc1nnco1 1,3,4-oxadiazole\n  CheckMol                        TMF02:r0:m0\n\n  5  5  0  1  0               999 V2000\n    0.0000    1.3409    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.2615    1.3409    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.4303    0.0000    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    1.8312    0.0000    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    1.1308    2.1515    0.0000 O   0 00  0  0  0  0  0  0  0  0  0  0\n  1  3 02  0  1  0  0\n  1  5 01  0  1  0  0\n  2  4 02  0  1  0  0\n  2  5 01  0  1  0  0\n  3  4 01  0  1  0  0\nM  END\n\n$$$$ \nc1cnsc1 isothiazole\n  CheckMol                        TMF02:r0:m0\n\n  5  5  0  1  0               999 V2000\n    0.4303    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.8312    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.3409    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.2615    1.3409    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    1.1308    2.1515    0.0000 S   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 01  0  1  0  0\n  1  3 02  0  1  0  0\n  2  4 02  0  1  0  0\n  3  5 01  0  1  0  0\n  4  5 01  0  1  0  0\nM  END\n\n$$$$ \nc1cscn1 thiazole\n  CheckMol                        TMF02:r0:m0\n\n  5  5  0  1  0               999 V2000\n    0.4303    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    1.3409    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.2615    1.3409    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.8312    0.0000    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    1.1308    2.1515    0.0000 S   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 02  0  1  0  0\n  1  4 01  0  1  0  0\n  2  5 01  0  1  0  0\n  3  4 02  0  1  0  0\n  3  5 01  0  1  0  0\nM  END\n\n$$$$ \nc1nncs1 1,3,4-thiadiazole\n  CheckMol                        TMF02:r0:m0\n\n  5  5  0  1  0               999 V2000\n    0.0000    1.3409    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.2615    1.3409    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.4303    0.0000    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    1.8312    0.0000    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    1.1308    2.1515    0.0000 S   0 00  0  0  0  0  0  0  0  0  0  0\n  1  3 02  0  1  0  0\n  1  5 01  0  1  0  0\n  2  4 02  0  1  0  0\n  2  5 01  0  1  0  0\n  3  4 01  0  1  0  0\nM  END\n\n$$$$ \nC1CCNCC1 piperidine\n  CheckMol                        TMF02:r0:m0\n\n  6  6  0  1  0               999 V2000\n    1.2124    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.4249    0.7000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    0.7000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.4249    2.1000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.1000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.2124    2.8000    0.0000 N   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  1  0  1  0  0\n  1  3  1  0  1  0  0\n  2  4  1  0  1  0  0\n  3  5  1  0  1  0  0\n  4  6  1  0  1  0  0\n  5  6  1  0  1  0  0\nM  END\n\n$$$$ \nC1CNCCN1 piperazine\n  CheckMol                        TMF02:r0:m0\n\n  6  6  0  1  0               999 V2000\n    0.0000    0.7007    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.1021    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.4224    0.7007    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.4224    2.1021    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.2112    0.0000    0.0000 N   0  0  0  0  0  0  0  0  0  0  0  0\n    1.2112    2.8028    0.0000 N   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  1  0  1  0  0\n  1  5  1  0  1  0  0\n  2  6  1  0  1  0  0\n  3  4  1  0  1  0  0\n  3  5  1  0  1  0  0\n  4  6  1  0  1  0  0\nM  END\n\n$$$$ \nC1=CNC=CC1 1,4-dihydropyridine\n  CheckMol                        TMF02:r0:m0\n\n  6  6  0  1  0               999 V2000\n    2.4249    0.7000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    0.7000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.4249    2.1000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.1000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.2124    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.2124    2.8000    0.0000 N   0  0  0  0  0  0  0  0  0  0  0  0\n  1  3  2  0  1  0  0\n  1  5  1  0  1  0  0\n  2  4  2  0  1  0  0\n  2  5  1  0  1  0  0\n  3  6  1  0  1  0  0\n  4  6  1  0  1  0  0\nM  END\n\n$$$$ \nc1ccncc1 pyridine\n  CheckMol                        TMF02:r0:m0\n\n  6  6  0  1  0               999 V2000\n    1.2087    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    0.6993    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4274    0.6993    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.0978    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4274    2.0978    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2087    2.7970    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 01  0  1  0  0\n  1  3 02  0  1  0  0\n  2  4 02  0  1  0  0\n  3  5 01  0  1  0  0\n  4  6 01  0  1  0  0\n  5  6 02  0  1  0  0\nM  END\n\n$$$$ \nc1ccnnc1 pyridazine\n  CheckMol                        TMF02:r0:m0\n\n  6  6  0  1  0               999 V2000\n    1.2112    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    0.7007    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4224    0.7007    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.1021    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4224    2.1021    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2112    2.8028    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 01  0  1  0  0\n  1  3 02  0  1  0  0\n  2  4 02  0  1  0  0\n  3  5 01  0  1  0  0\n  4  6 01  0  1  0  0\n  5  6 02  0  1  0  0\nM  END\n\n$$$$ \nc1cncnc1 pyrimidine\n  CheckMol                        TMF02:r0:m0\n\n  6  6  0  1  0               999 V2000\n    0.0000    0.6999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2098    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.0996    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4195    2.0996    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4195    0.6999    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2098    2.8095    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 01  0  1  0  0\n  1  3 02  0  1  0  0\n  2  5 02  0  1  0  0\n  3  6 01  0  1  0  0\n  4  5 01  0  1  0  0\n  4  6 02  0  1  0  0\nM  END\n\n$$$$ \nc1cnccn1 pyrazine\n  CheckMol                        TMF02:r0:m0\n\n  6  6  0  1  0               999 V2000\n    0.0000    0.6999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.0996    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4195    0.6999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4195    2.0996    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2098    0.0000    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2098    2.8095    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 02  0  1  0  0\n  1  5 01  0  1  0  0\n  2  6 01  0  1  0  0\n  3  4 01  0  1  0  0\n  3  5 02  0  1  0  0\n  4  6 02  0  1  0  0\nM  END\n\n$$$$ \nc1cnncn1 1,2,4-triazine\n  CheckMol                        TMF02:r0:m0\n\n  6  6  0  1  0               999 V2000\n    0.0000    2.0996    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    0.6999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4195    2.0996    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2098    2.8095    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2098    0.0000    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4195    0.6999    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 02  0  1  0  0\n  1  4 01  0  1  0  0\n  2  5 01  0  1  0  0\n  3  4 02  0  1  0  0\n  3  6 01  0  1  0  0\n  5  6 02  0  1  0  0\nM  END\n\n$$$$ \nc1nncnn1 1,2,4,5-tetrazine\n  CheckMol                        TMF02:r0:m0\n\n  6  6  0  1  0               999 V2000\n    0.0000    0.6999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4195    2.0996    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.0996    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2098    0.0000    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2098    2.8095    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4195    0.6999    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n  1  3 02  0  1  0  0\n  1  4 01  0  1  0  0\n  2  5 02  0  1  0  0\n  2  6 01  0  1  0  0\n  3  5 01  0  1  0  0\n  4  6 02  0  1  0  0\nM  END\n\n$$$$ \nc2ccc1[nH]ccc1c2 indole\n  CheckMol                        TMF02:r0:m0\n\n  9 10  0  3  0               999 V2000\n    0.0000    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.1000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    4.5792    1.4000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2124    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2124    2.8000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    3.7564    0.2674    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    3.7564    2.5326    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4249    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4249    2.1000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 02  0  1  0  0\n  1  4 01  0  1  0  0\n  2  5 01  0  1  0  0\n  3  6 02  0  1  0  0\n  3  7 01  0  1  0  0\n  4  8 02  0  1  0  0\n  5  9 02  0  1  0  0\n  6  8 01  0  1  0  0\n  7  9 01  0  1  0  0\n  8  9 01  0  2  0  0\nM  END\n\n$$$$ \nc2ncc1[nH]cnc1n2 purine\n  CheckMol                        TMF02:r0:m0\n\n  9 10  0  3  0               999 V2000\n    0.0000    0.7010    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    4.5767    1.4021    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2118    2.8041    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.1031    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2118    0.0000    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    3.7555    0.2704    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    3.7555    2.5337    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4236    0.7010    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4236    2.1031    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n  1  4 02  0  1  0  0\n  1  5 01  0  1  0  0\n  2  6 02  0  1  0  0\n  2  7 01  0  1  0  0\n  3  4 01  0  1  0  0\n  3  9 02  0  1  0  0\n  5  8 02  0  1  0  0\n  6  8 01  0  1  0  0\n  7  9 01  0  1  0  0\n  8  9 01  0  2  0  0\nM  END\n\n$$$$ \nc2ccc1ccccc1c2 naphthalene\n  CheckMol                        TMF02:r0:m0\n\n 10 11  0  3  0               999 V2000\n    0.0000    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.1000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    4.8497    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    4.8497    2.1000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2124    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2124    2.8000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    3.6373    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    3.6373    2.8000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4249    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4249    2.1000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 02  0  1  0  0\n  1  5 01  0  1  0  0\n  2  6 01  0  1  0  0\n  3  4 01  0  1  0  0\n  3  7 02  0  1  0  0\n  4  8 02  0  1  0  0\n  5  9 02  0  1  0  0\n  6 10 02  0  1  0  0\n  7  9 01  0  1  0  0\n  8 10 01  0  1  0  0\n  9 10 01  0  2  0  0\nM  END\n\n$$$$ \nc3ccc2cc1ccccc1cc2c3 anthracene\n  CheckMol                        TMF02:r0:m0\n\n 14 16  0  6  0               999 V2000\n    7.2747    2.1000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    7.2747    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.1000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    6.0623    2.8000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    6.0623    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2100    2.8000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2100    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    3.6399    2.8000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    3.6399    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    4.8499    2.1000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    4.8499    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4299    2.1000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4299    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 01  0  1  0  0\n  1  5 02  0  1  0  0\n  2  6 02  0  1  0  0\n  3  4 02  0  1  0  0\n  3  7 01  0  1  0  0\n  4  8 01  0  1  0  0\n  5 11 01  0  1  0  0\n  6 12 01  0  1  0  0\n  7 13 02  0  1  0  0\n  8 14 02  0  1  0  0\n  9 11 02  0  1  0  0\n  9 13 01  0  1  0  0\n 10 12 02  0  1  0  0\n 10 14 01  0  1  0  0\n 11 12 01  0  2  0  0\n 13 14 01  0  2  0  0\nM  END\n\n$$$$ \nc2ccc1ncccc1c2 quinoline\n  CheckMol                        TMF02:r0:m0\n\n 10 11  0  3  0               999 V2000\n    0.0000    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.1000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    4.8497    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    4.8497    2.1000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2124    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    3.6373    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2124    2.8000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    3.6373    2.8000    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4249    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4249    2.1000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 02  0  1  0  0\n  1  5 01  0  1  0  0\n  2  7 01  0  1  0  0\n  3  4 01  0  1  0  0\n  3  6 02  0  1  0  0\n  4  8 02  0  1  0  0\n  5  9 02  0  1  0  0\n  6  9 01  0  1  0  0\n  7 10 02  0  1  0  0\n  8 10 01  0  1  0  0\n  9 10 01  0  2  0  0\nM  END\n\n$$$$ \nc2ccc1cnccc1c2 isoquinoline\n  CheckMol                        TMF02:r0:m0\n\n 10 11  0  3  0               999 V2000\n    0.0000    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.0999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    4.8499    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2100    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2100    2.7999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    3.6399    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    3.6399    2.7999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    4.8499    2.0999    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4299    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4299    2.0999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 02  0  1  0  0\n  1  4 01  0  1  0  0\n  2  5 01  0  1  0  0\n  3  6 02  0  1  0  0\n  3  8 01  0  1  0  0\n  4  9 02  0  1  0  0\n  5 10 02  0  1  0  0\n  6  9 01  0  1  0  0\n  7  8 02  0  1  0  0\n  7 10 01  0  1  0  0\n  9 10 01  0  2  0  0\nM  END\n\n$$$$ \nc2ccc1nnccc1c2 cinnoline\n  CheckMol                        TMF02:r0:m0\n\n 10 11  0  3  0               999 V2000\n    0.0000    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.0999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    4.8499    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2100    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2100    2.7999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    3.6399    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    4.8499    2.0999    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    3.6399    2.7999    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4299    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4299    2.0999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 02  0  1  0  0\n  1  4 01  0  1  0  0\n  2  5 01  0  1  0  0\n  3  6 02  0  1  0  0\n  3  7 01  0  1  0  0\n  4  9 02  0  1  0  0\n  5 10 02  0  1  0  0\n  6  9 01  0  1  0  0\n  7  8 02  0  1  0  0\n  8 10 01  0  1  0  0\n  9 10 01  0  2  0  0\nM  END\n\n$$$$ \nc2ccc1ncncc1c2 quinazoline\n  CheckMol                        TMF02:r0:m0\n\n 10 11  0  3  0               999 V2000\n    0.0000    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.0999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    4.8499    2.0999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2100    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2100    2.7999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    3.6399    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    4.8499    0.7000    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    3.6399    2.7999    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4299    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4299    2.0999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 02  0  1  0  0\n  1  4 01  0  1  0  0\n  2  5 01  0  1  0  0\n  3  7 01  0  1  0  0\n  3  8 02  0  1  0  0\n  4  9 02  0  1  0  0\n  5 10 02  0  1  0  0\n  6  7 02  0  1  0  0\n  6  9 01  0  1  0  0\n  8 10 01  0  1  0  0\n  9 10 01  0  2  0  0\nM  END\n\n$$$$ \nc2ccc1nccnc1c2 quinoxaline\n  CheckMol                        TMF02:r0:m0\n\n 10 11  0  3  0               999 V2000\n    0.0000    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.0999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    4.8499    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    4.8499    2.0999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2100    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2100    2.7999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    3.6399    0.0000    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    3.6399    2.7999    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4299    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4299    2.0999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 02  0  1  0  0\n  1  5 01  0  1  0  0\n  2  6 01  0  1  0  0\n  3  4 01  0  1  0  0\n  3  7 02  0  1  0  0\n  4  8 02  0  1  0  0\n  5  9 02  0  1  0  0\n  6 10 02  0  1  0  0\n  7  9 01  0  1  0  0\n  8 10 01  0  1  0  0\n  9 10 01  0  2  0  0\nM  END\n\n$$$$ \nc2ccc1cnncc1c2 phthalazine\n  CheckMol                        TMF02:r0:m0\n\n 10 11  0  3  0               999 V2000\n    0.0000    2.0999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2100    2.7999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2100    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    3.6399    2.7999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    3.6399    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    4.8499    2.0999    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    4.8499    0.7000    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4299    2.0999    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4299    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n  1  2 02  0  1  0  0\n  1  3 01  0  1  0  0\n  2  4 01  0  1  0  0\n  3  9 02  0  1  0  0\n  4 10 02  0  1  0  0\n  5  7 02  0  1  0  0\n  5  9 01  0  1  0  0\n  6  8 02  0  1  0  0\n  6 10 01  0  1  0  0\n  7  8 01  0  1  0  0\n  9 10 01  0  2  0  0\nM  END\n\n$$$$ \nc3ccc2nc1ccccc1cc2c3 acridine\n  CheckMol                        TMF02:r0:m0\n\n 14 16  0  6  0               999 V2000\n    7.2746    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    7.2746    2.1000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.1000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    6.0622    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2124    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    6.0622    2.8000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    1.2124    2.8000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    3.6373    0.0000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    3.6373    2.8000    0.0000 N   0 00  0  0  0  0  0  0  0  0  0  0\n    4.8497    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4249    0.7000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    4.8497    2.1000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n    2.4249    2.1000    0.0000 C   0 00  0  0  0  0  0  0  0  0  0  0\n  1  3 01  0  1  0  0\n  1  5 02  0  1  0  0\n  2  4 01  0  1  0  0\n  2  6 02  0  1  0  0\n  3  7 02  0  1  0  0\n  4  8 02  0  1  0  0\n  5 11 01  0  1  0  0\n  6 12 01  0  1  0  0\n  7 13 01  0  1  0  0\n  8 14 01  0  1  0  0\n  9 11 02  0  1  0  0\n  9 12 01  0  1  0  0\n 10 13 02  0  1  0  0\n 10 14 01  0  1  0  0\n 11 13 01  0  2  0  0\n 12 14 02  0  2  0  0\nM  END\n\n$$$$ \nC1CCC3C(C1)CCC4C2CCCC2CCC34 steroid\n  CheckMol                        TMF02:r0:m0\n\n 17 20  0 10  0               999 V2000\n    0.0000    0.7000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    0.0000    2.1000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    8.2166    3.5000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.2124    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    7.3937    4.6326    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    1.2124    2.8000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    7.3937    2.3674    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    3.6373    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    4.8497    4.9000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    4.8497    0.7000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    3.6373    4.2000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.4249    0.7000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    6.0622    4.2000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    2.4249    2.1000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    6.0622    2.8000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    3.6373    2.8000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n    4.8497    2.1000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  1  0  1  0  0\n  1  4  1  0  1  0  0\n  2  6  1  0  1  0  0\n  3  5  1  0  1  0  0\n  3  7  1  0  1  0  0\n  4 12  1  0  1  0  0\n  5 13  1  0  1  0  0\n  6 14  1  0  1  0  0\n  7 15  1  0  1  0  0\n  8 10  1  0  1  0  0\n  8 12  1  0  1  0  0\n  9 11  1  0  1  0  0\n  9 13  1  0  1  0  0\n 10 17  1  0  1  0  0\n 11 16  1  0  1  0  0\n 12 14  1  0  2  0  0\n 13 15  1  0  2  0  0\n 14 16  1  0  1  0  0\n 15 17  1  0  1  0  0\n 16 17  1  0  2  0  0\nM  END\n',1);
/*!40000 ALTER TABLE `moldb_fpdef` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moldb_meta`
--

DROP TABLE IF EXISTS `moldb_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `moldb_meta` (
  `db_id` int(11) NOT NULL,
  `type` tinyint(4) unsigned NOT NULL DEFAULT '1' COMMENT '1 = substance, 2 = reaction, 3 = combined',
  `access` tinyint(4) unsigned NOT NULL DEFAULT '1' COMMENT '0=hidden, 1=read-only, 2=add/update, 3=full access',
  `name` varbinary(255) NOT NULL,
  `description` tinytext CHARACTER SET latin1 NOT NULL,
  `usemem` enum('T','F') NOT NULL DEFAULT 'F',
  `memstatus` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `digits` tinyint(4) unsigned NOT NULL DEFAULT '8',
  `subdirdigits` tinyint(4) unsigned NOT NULL DEFAULT '4',
  `trustedIP` varbinary(255) NOT NULL,
  PRIMARY KEY (`db_id`)
) ENGINE=MyISAM DEFAULT CHARSET=binary COMMENT='meta information about MolDB5R data collections';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moldb_meta`
--

LOCK TABLES `moldb_meta` WRITE;
/*!40000 ALTER TABLE `moldb_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `moldb_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moldb_molcfp`
--

DROP TABLE IF EXISTS `moldb_molcfp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `moldb_molcfp` (
  `mol_id` int(11) NOT NULL DEFAULT '0',
  `dfp01` bigint(20) NOT NULL,
  `hfp01` int(11) unsigned NOT NULL,
  `hfp02` int(11) unsigned NOT NULL,
  `hfp03` int(11) unsigned NOT NULL,
  `hfp04` int(11) unsigned NOT NULL,
  `hfp05` int(11) unsigned NOT NULL,
  `hfp06` int(11) unsigned NOT NULL,
  `hfp07` int(11) unsigned NOT NULL,
  `hfp08` int(11) unsigned NOT NULL,
  `hfp09` int(11) unsigned NOT NULL,
  `hfp10` int(11) unsigned NOT NULL,
  `hfp11` int(11) unsigned NOT NULL,
  `hfp12` int(11) unsigned NOT NULL,
  `hfp13` int(11) unsigned NOT NULL,
  `hfp14` int(11) unsigned NOT NULL,
  `hfp15` int(11) unsigned NOT NULL,
  `hfp16` int(11) unsigned NOT NULL,
  `n_h1bits` smallint(6) NOT NULL,
  PRIMARY KEY (`mol_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Combined dictionary-based and hash-based fingerprints';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moldb_molcfp`
--

LOCK TABLES `moldb_molcfp` WRITE;
/*!40000 ALTER TABLE `moldb_molcfp` DISABLE KEYS */;
/*!40000 ALTER TABLE `moldb_molcfp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moldb_molcfp_mem`
--

DROP TABLE IF EXISTS `moldb_molcfp_mem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `moldb_molcfp_mem` (
  `mol_id` int(11) DEFAULT NULL,
  `dfp01` bigint(20) NOT NULL,
  `hfp01` int(11) unsigned NOT NULL,
  `hfp02` int(11) unsigned NOT NULL,
  `hfp03` int(11) unsigned NOT NULL,
  `hfp04` int(11) unsigned NOT NULL,
  `hfp05` int(11) unsigned NOT NULL,
  `hfp06` int(11) unsigned NOT NULL,
  `hfp07` int(11) unsigned NOT NULL,
  `hfp08` int(11) unsigned NOT NULL,
  `hfp09` int(11) unsigned NOT NULL,
  `hfp10` int(11) unsigned NOT NULL,
  `hfp11` int(11) unsigned NOT NULL,
  `hfp12` int(11) unsigned NOT NULL,
  `hfp13` int(11) unsigned NOT NULL,
  `hfp14` int(11) unsigned NOT NULL,
  `hfp15` int(11) unsigned NOT NULL,
  `hfp16` int(11) unsigned NOT NULL,
  `n_h1bits` smallint(6) NOT NULL
) ENGINE=MEMORY DEFAULT CHARSET=latin1 COMMENT='Combined dictionary-based and hash-based fingerprints';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moldb_molcfp_mem`
--

LOCK TABLES `moldb_molcfp_mem` WRITE;
/*!40000 ALTER TABLE `moldb_molcfp_mem` DISABLE KEYS */;
/*!40000 ALTER TABLE `moldb_molcfp_mem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moldb_moldata`
--

DROP TABLE IF EXISTS `moldb_moldata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `moldb_moldata` (
  `mol_id` int(8) unsigned zerofill NOT NULL DEFAULT '00000000',
  `mol_name` varchar(255) NOT NULL,
  PRIMARY KEY (`mol_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moldb_moldata`
--

LOCK TABLES `moldb_moldata` WRITE;
/*!40000 ALTER TABLE `moldb_moldata` DISABLE KEYS */;
/*!40000 ALTER TABLE `moldb_moldata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moldb_molfgb`
--

DROP TABLE IF EXISTS `moldb_molfgb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `moldb_molfgb` (
  `mol_id` int(11) NOT NULL DEFAULT '0',
  `fg01` int(11) unsigned NOT NULL,
  `fg02` int(11) unsigned NOT NULL,
  `fg03` int(11) unsigned NOT NULL,
  `fg04` int(11) unsigned NOT NULL,
  `fg05` int(11) unsigned NOT NULL,
  `fg06` int(11) unsigned NOT NULL,
  `fg07` int(11) unsigned NOT NULL,
  `fg08` int(11) unsigned NOT NULL,
  `n_1bits` smallint(6) NOT NULL,
  PRIMARY KEY (`mol_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Functional group patterns';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moldb_molfgb`
--

LOCK TABLES `moldb_molfgb` WRITE;
/*!40000 ALTER TABLE `moldb_molfgb` DISABLE KEYS */;
/*!40000 ALTER TABLE `moldb_molfgb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moldb_molstat`
--

DROP TABLE IF EXISTS `moldb_molstat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `moldb_molstat` (
  `mol_id` int(11) NOT NULL DEFAULT '0',
  `n_atoms` smallint(6) NOT NULL DEFAULT '0',
  `n_bonds` smallint(6) NOT NULL DEFAULT '0',
  `n_rings` smallint(6) NOT NULL DEFAULT '0',
  `n_QA` smallint(6) NOT NULL DEFAULT '0',
  `n_QB` smallint(6) NOT NULL DEFAULT '0',
  `n_chg` smallint(6) NOT NULL DEFAULT '0',
  `n_C1` smallint(6) NOT NULL DEFAULT '0',
  `n_C2` smallint(6) NOT NULL DEFAULT '0',
  `n_C` smallint(6) NOT NULL DEFAULT '0',
  `n_CHB1p` smallint(6) NOT NULL DEFAULT '0',
  `n_CHB2p` smallint(6) NOT NULL DEFAULT '0',
  `n_CHB3p` smallint(6) NOT NULL DEFAULT '0',
  `n_CHB4` smallint(6) NOT NULL DEFAULT '0',
  `n_O2` smallint(6) NOT NULL DEFAULT '0',
  `n_O3` smallint(6) NOT NULL DEFAULT '0',
  `n_N1` smallint(6) NOT NULL DEFAULT '0',
  `n_N2` smallint(6) NOT NULL DEFAULT '0',
  `n_N3` smallint(6) NOT NULL DEFAULT '0',
  `n_S` smallint(6) NOT NULL DEFAULT '0',
  `n_SeTe` smallint(6) NOT NULL DEFAULT '0',
  `n_F` smallint(6) NOT NULL DEFAULT '0',
  `n_Cl` smallint(6) NOT NULL DEFAULT '0',
  `n_Br` smallint(6) NOT NULL DEFAULT '0',
  `n_I` smallint(6) NOT NULL DEFAULT '0',
  `n_P` smallint(6) NOT NULL DEFAULT '0',
  `n_B` smallint(6) NOT NULL DEFAULT '0',
  `n_Met` smallint(6) NOT NULL DEFAULT '0',
  `n_X` smallint(6) NOT NULL DEFAULT '0',
  `n_b1` smallint(6) NOT NULL DEFAULT '0',
  `n_b2` smallint(6) NOT NULL DEFAULT '0',
  `n_b3` smallint(6) NOT NULL DEFAULT '0',
  `n_bar` smallint(6) NOT NULL DEFAULT '0',
  `n_C1O` smallint(6) NOT NULL DEFAULT '0',
  `n_C2O` smallint(6) NOT NULL DEFAULT '0',
  `n_CN` smallint(6) NOT NULL DEFAULT '0',
  `n_XY` smallint(6) NOT NULL DEFAULT '0',
  `n_r3` smallint(6) NOT NULL DEFAULT '0',
  `n_r4` smallint(6) NOT NULL DEFAULT '0',
  `n_r5` smallint(6) NOT NULL DEFAULT '0',
  `n_r6` smallint(6) NOT NULL DEFAULT '0',
  `n_r7` smallint(6) NOT NULL DEFAULT '0',
  `n_r8` smallint(6) NOT NULL DEFAULT '0',
  `n_r9` smallint(6) NOT NULL DEFAULT '0',
  `n_r10` smallint(6) NOT NULL DEFAULT '0',
  `n_r11` smallint(6) NOT NULL DEFAULT '0',
  `n_r12` smallint(6) NOT NULL DEFAULT '0',
  `n_r13p` smallint(6) NOT NULL DEFAULT '0',
  `n_rN` smallint(6) NOT NULL DEFAULT '0',
  `n_rN1` smallint(6) NOT NULL DEFAULT '0',
  `n_rN2` smallint(6) NOT NULL DEFAULT '0',
  `n_rN3p` smallint(6) NOT NULL DEFAULT '0',
  `n_rO` smallint(6) NOT NULL DEFAULT '0',
  `n_rO1` smallint(6) NOT NULL DEFAULT '0',
  `n_rO2p` smallint(6) NOT NULL DEFAULT '0',
  `n_rS` smallint(6) NOT NULL DEFAULT '0',
  `n_rX` smallint(6) NOT NULL DEFAULT '0',
  `n_rar` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`mol_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Molecular statistics';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moldb_molstat`
--

LOCK TABLES `moldb_molstat` WRITE;
/*!40000 ALTER TABLE `moldb_molstat` DISABLE KEYS */;
/*!40000 ALTER TABLE `moldb_molstat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moldb_molstat_mem`
--

DROP TABLE IF EXISTS `moldb_molstat_mem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `moldb_molstat_mem` (
  `mol_id` int(11) NOT NULL DEFAULT '0',
  `n_atoms` smallint(6) NOT NULL DEFAULT '0',
  `n_bonds` smallint(6) NOT NULL DEFAULT '0',
  `n_rings` smallint(6) NOT NULL DEFAULT '0',
  `n_QA` smallint(6) NOT NULL DEFAULT '0',
  `n_QB` smallint(6) NOT NULL DEFAULT '0',
  `n_chg` smallint(6) NOT NULL DEFAULT '0',
  `n_C1` smallint(6) NOT NULL DEFAULT '0',
  `n_C2` smallint(6) NOT NULL DEFAULT '0',
  `n_C` smallint(6) NOT NULL DEFAULT '0',
  `n_CHB1p` smallint(6) NOT NULL DEFAULT '0',
  `n_CHB2p` smallint(6) NOT NULL DEFAULT '0',
  `n_CHB3p` smallint(6) NOT NULL DEFAULT '0',
  `n_CHB4` smallint(6) NOT NULL DEFAULT '0',
  `n_O2` smallint(6) NOT NULL DEFAULT '0',
  `n_O3` smallint(6) NOT NULL DEFAULT '0',
  `n_N1` smallint(6) NOT NULL DEFAULT '0',
  `n_N2` smallint(6) NOT NULL DEFAULT '0',
  `n_N3` smallint(6) NOT NULL DEFAULT '0',
  `n_S` smallint(6) NOT NULL DEFAULT '0',
  `n_SeTe` smallint(6) NOT NULL DEFAULT '0',
  `n_F` smallint(6) NOT NULL DEFAULT '0',
  `n_Cl` smallint(6) NOT NULL DEFAULT '0',
  `n_Br` smallint(6) NOT NULL DEFAULT '0',
  `n_I` smallint(6) NOT NULL DEFAULT '0',
  `n_P` smallint(6) NOT NULL DEFAULT '0',
  `n_B` smallint(6) NOT NULL DEFAULT '0',
  `n_Met` smallint(6) NOT NULL DEFAULT '0',
  `n_X` smallint(6) NOT NULL DEFAULT '0',
  `n_b1` smallint(6) NOT NULL DEFAULT '0',
  `n_b2` smallint(6) NOT NULL DEFAULT '0',
  `n_b3` smallint(6) NOT NULL DEFAULT '0',
  `n_bar` smallint(6) NOT NULL DEFAULT '0',
  `n_C1O` smallint(6) NOT NULL DEFAULT '0',
  `n_C2O` smallint(6) NOT NULL DEFAULT '0',
  `n_CN` smallint(6) NOT NULL DEFAULT '0',
  `n_XY` smallint(6) NOT NULL DEFAULT '0',
  `n_r3` smallint(6) NOT NULL DEFAULT '0',
  `n_r4` smallint(6) NOT NULL DEFAULT '0',
  `n_r5` smallint(6) NOT NULL DEFAULT '0',
  `n_r6` smallint(6) NOT NULL DEFAULT '0',
  `n_r7` smallint(6) NOT NULL DEFAULT '0',
  `n_r8` smallint(6) NOT NULL DEFAULT '0',
  `n_r9` smallint(6) NOT NULL DEFAULT '0',
  `n_r10` smallint(6) NOT NULL DEFAULT '0',
  `n_r11` smallint(6) NOT NULL DEFAULT '0',
  `n_r12` smallint(6) NOT NULL DEFAULT '0',
  `n_r13p` smallint(6) NOT NULL DEFAULT '0',
  `n_rN` smallint(6) NOT NULL DEFAULT '0',
  `n_rN1` smallint(6) NOT NULL DEFAULT '0',
  `n_rN2` smallint(6) NOT NULL DEFAULT '0',
  `n_rN3p` smallint(6) NOT NULL DEFAULT '0',
  `n_rO` smallint(6) NOT NULL DEFAULT '0',
  `n_rO1` smallint(6) NOT NULL DEFAULT '0',
  `n_rO2p` smallint(6) NOT NULL DEFAULT '0',
  `n_rS` smallint(6) NOT NULL DEFAULT '0',
  `n_rX` smallint(6) NOT NULL DEFAULT '0',
  `n_rar` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`mol_id`)
) ENGINE=MEMORY DEFAULT CHARSET=latin1 COMMENT='Molecular statistics';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moldb_molstat_mem`
--

LOCK TABLES `moldb_molstat_mem` WRITE;
/*!40000 ALTER TABLE `moldb_molstat_mem` DISABLE KEYS */;
/*!40000 ALTER TABLE `moldb_molstat_mem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moldb_molstruc`
--

DROP TABLE IF EXISTS `moldb_molstruc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `moldb_molstruc` (
  `mol_id` int(11) NOT NULL DEFAULT '0',
  `struc` mediumblob NOT NULL,
  PRIMARY KEY (`mol_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moldb_molstruc`
--

LOCK TABLES `moldb_molstruc` WRITE;
/*!40000 ALTER TABLE `moldb_molstruc` DISABLE KEYS */;
/*!40000 ALTER TABLE `moldb_molstruc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moldb_pic2d`
--

DROP TABLE IF EXISTS `moldb_pic2d`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `moldb_pic2d` (
  `mol_id` int(11) NOT NULL DEFAULT '0',
  `type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1 = png',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0 = does not exist, 1 = OK, 2 = OK, but do not show, 3 = to be created/updated, 4 = to be deleted',
  `svg` blob NOT NULL,
  PRIMARY KEY (`mol_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Housekeeping for 2D depiction';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moldb_pic2d`
--

LOCK TABLES `moldb_pic2d` WRITE;
/*!40000 ALTER TABLE `moldb_pic2d` DISABLE KEYS */;
/*!40000 ALTER TABLE `moldb_pic2d` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plate_info`
--

DROP TABLE IF EXISTS `plate_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plate_info` (
  `mol_id` int(8) unsigned zerofill NOT NULL DEFAULT '00000000',
  `plate_num` int(3) DEFAULT NULL,
  `plate_row` varchar(1) DEFAULT NULL,
  `plate_col` int(3) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plate_info`
--

LOCK TABLES `plate_info` WRITE;
/*!40000 ALTER TABLE `plate_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `plate_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prediction_list`
--

DROP TABLE IF EXISTS `prediction_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prediction_list` (
  `pred_id` int(11) NOT NULL AUTO_INCREMENT,
  `pred_name` varchar(255) NOT NULL,
  `model_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(40) NOT NULL,
  `printout` longtext,
  PRIMARY KEY (`pred_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prediction_list`
--

LOCK TABLES `prediction_list` WRITE;
/*!40000 ALTER TABLE `prediction_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `prediction_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prediction_mols`
--

DROP TABLE IF EXISTS `prediction_mols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prediction_mols` (
  `mol_id` int(11) NOT NULL,
  `pred_id` int(11) NOT NULL,
  `main_class` varchar(20) NOT NULL,
  `distribution` text NOT NULL,
  `lhood` double NOT NULL,
  UNIQUE KEY `mol_id` (`mol_id`,`pred_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prediction_mols`
--

LOCK TABLES `prediction_mols` WRITE;
/*!40000 ALTER TABLE `prediction_mols` DISABLE KEYS */;
/*!40000 ALTER TABLE `prediction_mols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sdftags`
--

DROP TABLE IF EXISTS `sdftags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sdftags` (
  `mol_id` int(8) unsigned zerofill NOT NULL DEFAULT '00000000',
  `external_predictor` double DEFAULT NULL,
  `classifier` varchar(80) DEFAULT NULL,
  `activity_class` varchar(40) DEFAULT NULL,
  `z_score` double DEFAULT NULL,
  `compound_name` varchar(255) DEFAULT NULL,
  `plate_row` varchar(10) DEFAULT NULL,
  `plate_column` int(11) DEFAULT NULL,
  `plate_number` int(11) DEFAULT NULL,
  `cas_no` varchar(40) DEFAULT NULL,
  `chembankid` int(11) DEFAULT NULL,
  `compositez` double DEFAULT NULL,
  `reproducibility` double DEFAULT NULL,
  `pubchem_compound_cid` int(11) DEFAULT NULL,
  `rankscore` int(11) DEFAULT NULL,
  `p_value` double NOT NULL,
  `external_value` double DEFAULT NULL,
  `class` varchar(80) DEFAULT NULL,
  `standard_value` int(11) DEFAULT NULL,
  `standard_units` varchar(80) DEFAULT NULL,
  `standard_type` varchar(160) DEFAULT NULL,
  `chembl_id` int(11) DEFAULT NULL,
  `vendor_id` varchar(40) DEFAULT NULL,
  `logd` double DEFAULT NULL,
  `rgyr` double DEFAULT NULL,
  `hcpsa` double DEFAULT NULL,
  `frotb` double DEFAULT NULL,
  `smiles` text,
  `canonical_smiles` text,
  `caco2` double DEFAULT NULL,
  PRIMARY KEY (`mol_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sdftags`
--

LOCK TABLES `sdftags` WRITE;
/*!40000 ALTER TABLE `sdftags` DISABLE KEYS */;
/*!40000 ALTER TABLE `sdftags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tanimoto`
--

DROP TABLE IF EXISTS `tanimoto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tanimoto` (
  `mol_id1` int(11) NOT NULL,
  `mol_id2` int(11) NOT NULL,
  `ext` decimal(5,4) NOT NULL,
  `kr` decimal(5,4) NOT NULL,
  PRIMARY KEY (`mol_id1`,`mol_id2`),
  KEY `ext` (`ext`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tanimoto`
--

LOCK TABLES `tanimoto` WRITE;
/*!40000 ALTER TABLE `tanimoto` DISABLE KEYS */;
/*!40000 ALTER TABLE `tanimoto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timeout_mols`
--

DROP TABLE IF EXISTS `timeout_mols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timeout_mols` (
  `mol_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timeout_mols`
--

LOCK TABLES `timeout_mols` WRITE;
/*!40000 ALTER TABLE `timeout_mols` DISABLE KEYS */;
/*!40000 ALTER TABLE `timeout_mols` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-08-08  3:16:50
